
function getAnalysis(price){
	
	if(price == '' || price.trim() == '' || price == undefined ){
		$('#price_analysis_msg').html(''); ;
	}
	
	price = parseInt(price);
	
	var msg = '';
	
	if(price <= parseInt($('#analysisA').val())){
		msg = 'Analysis : A';
	}else if(price <= parseInt($('#analysisB').val())){
		msg = 'Analysis : B';
	}else if(price <= parseInt($('#analysisC').val())){
		msg = 'Analysis : C';
	}
	
	$('#price_analysis_msg').html(msg);
	
	
	
}

var warehouse_count = 0;

function addRows() {
  $('#warehouse_container').html('');
  warehouse_count = $('#warehouse_count').val();
  var html = '';

  for(var i = 1; i <= warehouse_count; i++){
    html += '<div id="container_id'+i+'">';
    html += '<label>Enter warehouse name </label>';
    html += '<input type="text" name="warehouse_name'+i+'" id="warehouse_id'+i+'" >';

    html += '<label>Enter Racks </label>';
    html += '<input type="number" name="warehouse_rack_count'+i+'" id="warehouse_rack_count'+i+'" >';

    html += '</div><br>';

    html += '<hr>';
  }

  $('#warehouse_container').html(html);
  $('#generateracks').show();
}

function AddRacks(){
  $('#generateracks').hide();
  $('#warehouse_container').hide();
  
  var map = {};

  for(var i = 1; i <= warehouse_count; i++){
    map[$("#warehouse_id"+i).val()] = $("#warehouse_rack_count"+i).val();
  }

  console.log(map);

  var html = '';

  for (var key in map) {
    html += '<label>enter rack for '+key+'</label>';
    html += '<br>';

    for(var i = 1; i <= map[key]; i++){
      html += '<label>Enter Rack name </label>';
      html += '<input type="text" name="rack_name'+i+'" id="rack_id_'+key+'_'+i+'" >';
      html += '<br>';
    }

    html += '<br><hr>';
  }

  html += '<input type="button" id="submitWarehouseRacks" onclick="submitWarehouseRacks()" value="FINISH" style="">';

  $('#rack_container').html(html);
}

function submitWarehouseRacks(){
  var rackData = {};

  for (var i = 1; i <= warehouse_count; i++) {
    var warehouseName = $("#warehouse_id" + i).val();
    var rackCount = $("#warehouse_rack_count" + i).val();
    var racks = [];

    for (var j = 1; j <= rackCount; j++) {
      var rackName = $("#rack_id_"+warehouseName+'_' + j).val();
      racks.push(rackName);
    }

    rackData[warehouseName] = racks;
  }

//$(document).ready(function() {
	$.ajax({
    url: '/submitWarehouseRacks',
    type: 'POST',
    data: JSON.stringify(rackData),
    contentType: 'application/json',
    dataType: 'json',
  	//contentType: 'json',
    success: function(response) {
      alert('Warehouse racks submitted successfully!');
    },
    error: function(error) {
      console.log(error);
      if(error.responseText == 'Warehouse racks submitted successfully!'){
		alert(error.responseText);
		location.reload();  
	  }else{
		 alert('Error occurred while submitting warehouse racks!'); 
	  }
      
    }
  });

//});
	
  // Perform AJAX call to submit the warehouse rack data
  }
  
  
  function getallRacksByWarehouse(){
	  
	  var warehousename =  $('#warehouse_name').val();
	  console.log(warehousename)
	  
	  //write ajax call
	  
	  $.ajax({
            method: "GET",
		  url: "/getallRacksByWarehouse?warehousename="+warehousename,
            //data: { Role: $(this).val() },
            success:function (data) {
				console.log(data);
              
              var data1 = JSON.parse(data);
              
              console.log(data1);
			var html = '<option></option>';
			for (var i = 0; i < data1.length; i++) {  
			html += "<option>"+data1[i]+"</option>";
			}
			$('#rack_number').html(html);
            }
        });
	  
	  
  }
  
  function deletewarehouse(element){
	  
	  console.log(element.id);
	  var result = confirm("Want to delete a warehouse? Are you sure ?  ");
	  
	  if(result){
		  $.ajax({
            method: "GET",
            url: "/deletewarehouse?id="+element.id,
            //data: { Role: $(this).val() },
            success:function (data) {
				console.log(data);
              
             // var data1 = JSON.parse(data);
              alert('warehouse deleted successfully');
             location.reload();
            }
        });
	  
	  }
	   
	  
	  
  }
  

  
  