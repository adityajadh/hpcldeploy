
        function createPages() {
            var numPages = parseInt(document.getElementById("numPages").value);

            var dynamicPages = document.getElementById("dynamicPages");
            dynamicPages.innerHTML = "";

            for (var i = 0; i < numPages; i++) {
                var page = document.createElement("div");
                page.classList.add("page");

                var nameLabel = document.createElement("label");
                nameLabel.textContent = "Name: ";
                var nameInput = document.createElement("input");
                nameInput.type = "text";

                var rackLabel = document.createElement("label");
                rackLabel.textContent = "Rack: ";
                var rackInput = document.createElement("input");
                rackInput.type = "number";

                page.appendChild(nameLabel);
                page.appendChild(nameInput);
                page.appendChild(document.createElement("br"));
                page.appendChild(rackLabel);
                page.appendChild(rackInput);

                dynamicPages.appendChild(page);
            }
        }

        function submitValues() {
            var pages = document.getElementsByClassName("page");

            for (var i = 0; i < pages.length; i++) {
                var name = pages[i].getElementsByTagName("input")[0].value;
                var rack = pages[i].getElementsByTagName("input")[1].value;

                // Here you can perform any desired action with the submitted values
                console.log("Name:", name, "Rack:", rack);
                
            }
        }
        function submitValues() {
  var pages = document.getElementsByClassName("page");
  var racks = [];

  for (var i = 0; i < pages.length; i++) {
    var name = pages[i].getElementsByTagName("input")[0].value;
    var rack = pages[i].getElementsByTagName("input")[1].value;

    racks.push({ name: name, rack: rack });
  }

  // Send the racks data to the Spring Boot backend
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "/api/racks", true);
  xhr.setRequestHeader("Content-Type", "application/json");

  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
      var response = JSON.parse(xhr.responseText);
      console.log("Response:", response);
    }
  };

  xhr.send(JSON.stringify(racks));
}
