package net.hpcl.inventory.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Supplier;
import net.hpcl.inventory.repository.SupplierRepository;

@Service
public class SupplierServiceImpl implements SupplierService {
    @Autowired
    private SupplierRepository supplierRepo;

    @Override
    public Supplier createUser(Supplier supplier) {
        return supplierRepo.save(supplier);
    }

    @Override
    public boolean checkEmail(String email) {
        return supplierRepo.existsByEmail(email);
    }

    @Override
    public List<Supplier> getAllSupplierDetails() {
        return supplierRepo.findAll();
    }

    @Override
    public Optional<Supplier> getSupplierById(Long id) {
        return supplierRepo.findById(id);
    }

  /*  @Override
    public void updateSupplier(Long id, Supplier updatedSupplier) {
        Optional<Supplier> supplier = supplierRepo.findById(id);
        if (supplier.isPresent()) {
            Supplier existingSupplier = supplier.get();
            existingSupplier.setSname(updatedSupplier.getSname());
            existingSupplier.setEmail(updatedSupplier.getEmail());
            // Set other updated fields
            supplierRepo.save(existingSupplier);
        }
    } */
    @Override
    public Supplier updateSupplier(Long id, Supplier updatedSupplier) {
        Optional<Supplier> supplierOptional = supplierRepo.findById(id);
        if (supplierOptional.isPresent()) {
            Supplier existingSupplier = supplierOptional.get();
            existingSupplier.setSname(updatedSupplier.getSname());
            existingSupplier.setContact_no(updatedSupplier.getContact_no());
            existingSupplier.setErp_code(updatedSupplier.getErp_code());
            existingSupplier.setSaddress(updatedSupplier.getSaddress());
            existingSupplier.setEmail(updatedSupplier.getEmail());
            existingSupplier.setSupplier_type(updatedSupplier.getSupplier_type());
            existingSupplier.setGst_no(updatedSupplier.getGst_no());
            existingSupplier.setImageName(updatedSupplier.getImageName());
            // Update other properties of the Supplier entity as needed
            supplierRepo.save(existingSupplier);
        }
		return updatedSupplier;
    }


    @Override
    public void deleteSupplier(Long id) {
        supplierRepo.deleteById(id);
    }

    @Override
    public void deletesupplierDetails(Long id) {
        // Perform additional operations for deleting supplier details, if needed
        supplierRepo.deleteById(id);
    }

    @Override
    public List<String> getAllSnames() {
        List<Supplier> suppliers = supplierRepo.findAll();
        return suppliers.stream()
                .map(Supplier::getSname)
                .collect(Collectors.toList());
    }
}
