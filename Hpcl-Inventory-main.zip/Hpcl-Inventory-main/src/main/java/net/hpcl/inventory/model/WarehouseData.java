package net.hpcl.inventory.model;

public class WarehouseData {
    private String warehouseName;
    private String[] racks;

    public String getWarehouseName() {
        return warehouseName;
    }

    public void setWarehouseName(String warehouseName) {
        this.warehouseName = warehouseName;
    }

    public String[] getRacks() {
        return racks;
    }

    public void setRacks(String[] racks) {
        this.racks = racks;
    }
}

