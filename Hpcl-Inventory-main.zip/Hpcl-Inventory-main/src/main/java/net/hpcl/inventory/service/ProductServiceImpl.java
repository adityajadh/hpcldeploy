/*package net.javaguides.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.model.Product;
import net.javaguides.springboot.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProductDetails() {
        return productRepository.findAll();
    }

    @Override
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    @Override
    public void updateProduct(Long id, Product updatedProduct) {
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            product.setProduct_id(updatedProduct.getProduct_id());
            product.setOpening_stock(updatedProduct.getOpening_stock());
            product.setQuantity(updatedProduct.getQuantity());
            product.setPrice(updatedProduct.getPrice());
            product.setPname(updatedProduct.getPname());
            product.setWarehouse_name(updatedProduct.getWarehouse_name());
            product.setRack_number(updatedProduct.getRack_number());
            product.setMachine_name(updatedProduct.getMachine_name());
            product.setSupplier(updatedProduct.getSupplier());
            product.setVDE(updatedProduct.getVDE());

            productRepository.save(product);
        } else {
            throw new IllegalArgumentException("Invalid product id: " + id);
        }
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public void deleteProductDetails(Long id) {
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            productRepository.delete(product);
        } else {
            throw new IllegalArgumentException("Invalid product id: " + id);
        }
    }

	@Override
	public List<String> getProductNames() {
		return productRepository.getProductNames();
	}

}
*/
/*package net.hpcl.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Product;
import net.hpcl.inventory.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProductDetails() {
        return productRepository.findAll();
    }

    @Override
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    @Override
    public void updateProduct(Long id, Product updatedProduct) {
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            product.setId(updatedProduct.getId());
            product.setProduct_id(updatedProduct.getProduct_id());
            product.setOpening_stock(updatedProduct.getOpening_stock());
            product.setQuantity(updatedProduct.getQuantity());
            product.setPrice(updatedProduct.getPrice());
            product.setPname(updatedProduct.getPname());
            product.setWarehouse_name(updatedProduct.getWarehouse_name());
            product.setRack_number(updatedProduct.getRack_number());
            product.setMachine_name(updatedProduct.getMachine_name());
            product.setSupplier(updatedProduct.getSupplier());
            product.setVDE(updatedProduct.getVDE());

            productRepository.save(product);
        } else {
            throw new IllegalArgumentException("Invalid product id: " + id);
        }
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public void deleteProductDetails(Long id) {
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            productRepository.delete(product);
        } else {
            throw new IllegalArgumentException("Invalid product id: " + id);
        }
    }

    @Override
    public List<String> getProductNames() {
        return productRepository.getProductNames();
    }

    @Override
    public List<String> getAllSnames() {
        // Implement the logic to retrieve all supplier names
        // You can use the corresponding repository method if available, or any other approach
        return null;
    }

    @Override
    public List<String> getAllNames() {
        // Implement the logic to retrieve all warehouse names
        // You can use the corresponding repository method if available, or any other approach
        return null;
    }

    @Override
    public List<String> getAllRacksByWarehouse(String warehousename) {
        // Implement the logic to retrieve all rack names based on the warehouse name
        // You can use the corresponding repository method if available, or any other approach
        return null;
    }
    
    @Override
    public List<Product> searchProducts(String keyword) {
        // Implementation for searching products by name or ID
        List<Product> matchingProducts = productRepository.findByNameContainingIgnoreCaseOrIdContainingIgnoreCase(keyword, keyword);
        return matchingProducts;
    }
}
*/
package net.hpcl.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Product;
import net.hpcl.inventory.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;

    @Autowired
    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public Product createProduct(Product product) {
        // Calculate pname if it's not already present in the database
        String calculatedPname = calculatePname(product.getPname());
        product.setPname(calculatedPname);

        // Calculate the opening stock and handle critical items
        calculateOpeningStock(product);

        // Save the product
        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProductDetails() {
        return productRepository.findAll();
    }

    @Override
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    @Override
    public void updateProduct(Long id, Product updatedProduct) {
        Optional<Product> productOptional = productRepository.findById(id);
        if (productOptional.isPresent()) {
            Product product = productOptional.get();
            product.setId(updatedProduct.getId());
            product.setProduct_id(updatedProduct.getProduct_id());
            product.setOpening_stock(updatedProduct.getOpening_stock());
            product.setQuantity(updatedProduct.getQuantity());
            product.setPrice(updatedProduct.getPrice());
            product.setPname(updatedProduct.getPname());
            product.setWarehouse_name(updatedProduct.getWarehouse_name());
            product.setRack_number(updatedProduct.getRack_number());
            product.setMachine_name(updatedProduct.getMachine_name());
            product.setSupplier(updatedProduct.getSupplier());
            product.setVDE(updatedProduct.getVDE());

            // Calculate the opening stock and handle critical items
            calculateOpeningStock(product);

            productRepository.save(product);
        } else {
            throw new IllegalArgumentException("Invalid product id: " + id);
        }
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public void deleteProductDetails(Long id) {
        productRepository.deleteById(id);
    }

    @Override
    public List<String> getProductNames() {
        return productRepository.getProductNames();
    }

    @Override
    public List<String> getAllSnames() {
        return productRepository.getAllSnames();
    }

    @Override
    public List<String> getAllNames() {
        return productRepository.getAllNames();
    }

    @Override
    public List<String> getAllRacksByWarehouse(String warehousename) {
        return productRepository.getAllRacksByWarehouse(warehousename);
    }
    
    @Override
    public List<Product> searchProducts(String keyword) {
        return productRepository.findByNameContainingIgnoreCaseOrIdContainingIgnoreCase(keyword, keyword);
    }

    private String calculatePname(String pname) {
        // Check if pname already exists in the database
        List<String> existingPnames = productRepository.getProductNames();
        if (existingPnames.contains(pname)) {
            // If pname already exists, calculate a modified pname
            return pname + "_Modified";
        }
        return pname;
    }

    private void calculateOpeningStock(Product product) {
        int openingStock = Integer.parseInt(product.getOpening_stock());
        if (openingStock < 10) {
            // Set a flag or mark the product as critical
            product.setPname(product.getPname() + " (Critical)");
        }
    }

	@Override
	public List<Product> search(String keyword) {
		if(keyword !=null) {
			return productRepository.search(keyword);
		}
		return productRepository.findAll();
	}
}

