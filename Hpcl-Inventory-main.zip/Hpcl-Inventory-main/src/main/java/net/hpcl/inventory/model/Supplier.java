package net.hpcl.inventory.model;
import javax.persistence.*;

@Entity
@Table(name="supplier")
public class Supplier {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long s_id;
	private String contact_no;
	private String sname;
	private String erp_code;
	private String saddress;
	private String email;
	private String supplier_type;
	private String gst_no;
	private String imageName;
	
	@Override
	public String toString() {
		return "Supplier [s_id=" + s_id + ", contact_no=" + contact_no + ", sname=" + sname + ", erp_code=" + erp_code
				+ ", saddress=" + saddress + ", email=" + email + ", supplier_type=" + supplier_type + ", gst_no="
				+ gst_no + ", imageName=" + imageName + "]";
	}
	
	public long getS_id() {
		return s_id;
	}
	public void setS_id(long s_id) {
		this.s_id = s_id;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getErp_code() {
		return erp_code;
	}
	public void setErp_code(String erp_code) {
		this.erp_code = erp_code;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSupplier_type() {
		return supplier_type;
	}
	public void setSupplier_type(String supplier_type) {
		this.supplier_type = supplier_type;
	}
	public String getGst_no() {
		return gst_no;
	}
	public void setGst_no(String gst_no) {
		this.gst_no = gst_no;
	}
	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	
	
}
