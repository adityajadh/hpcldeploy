package net.hpcl.inventory.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Analysis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int maxValueA;
    private int maxValueB;
    private int maxValueC;
	
    
    public Analysis() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Analysis(Long id, int maxValueA, int maxValueB, int maxValueC) {
		super();
		this.id = id;
		this.maxValueA = maxValueA;
		this.maxValueB = maxValueB;
		this.maxValueC = maxValueC;
	}


	@Override
	public String toString() {
		return "Analysis [id=" + id + ", maxValueA=" + maxValueA + ", maxValueB=" + maxValueB + ", maxValueC="
				+ maxValueC + "]";
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public int getMaxValueA() {
		return maxValueA;
	}


	public void setMaxValueA(int maxValueA) {
		this.maxValueA = maxValueA;
	}


	public int getMaxValueB() {
		return maxValueB;
	}


	public void setMaxValueB(int maxValueB) {
		this.maxValueB = maxValueB;
	}


	public int getMaxValueC() {
		return maxValueC;
	}


	public void setMaxValueC(int maxValueC) {
		this.maxValueC = maxValueC;
	}

}
