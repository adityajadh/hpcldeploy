package net.hpcl.inventory.service;

import java.util.List;

import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Analysis;
@Service
public interface AnalysisService {
    List<Analysis> getAllAnalysis();
    Analysis getAnalysisById(Long id);
    Analysis saveAnalysis(Analysis analysis);
    void deleteAnalysis(Long id);
}
