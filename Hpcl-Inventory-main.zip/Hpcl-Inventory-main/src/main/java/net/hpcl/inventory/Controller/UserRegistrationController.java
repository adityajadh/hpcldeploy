package net.hpcl.inventory.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import net.hpcl.inventory.Controller.dto.UserRegistrationDto;
import net.hpcl.inventory.model.User;
import net.hpcl.inventory.service.UserService;

import java.util.List;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController {

    private UserService userService;

    public UserRegistrationController(UserService userService) {
        this.userService = userService;
    }

    @ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto() {
        return new UserRegistrationDto();
    }

    @GetMapping
    public String showRegistrationForm() {
        return "registration";
    }

    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") UserRegistrationDto registrationDto) {
        userService.save(registrationDto);
        return "redirect:/registration?success";
    }

    @GetMapping("/showuser")
    public String showUserList(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "showuser";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        User user = userService.getUserById(id);
        if (user == null) {
            // Handle the case when the user is not found
            return "redirect:/registration/showuser";
        }
        model.addAttribute("user", user);
        return "edituser";
    }

    @PostMapping("/edit/{id}")
    public String updateUser(@PathVariable("id") Long id, @ModelAttribute("user") UserRegistrationDto userDto,
                             RedirectAttributes redirectAttributes) {
        User existingUser = userService.getUserById(id);
        if (existingUser == null) {
            // Handle the case when the user is not found
            return "redirect:/registration/showuser";
        }

        existingUser.setFirstName(userDto.getFirstName());
        existingUser.setLastName(userDto.getLastName());
        existingUser.setEmail(userDto.getEmail());

        userService.save(existingUser);

        redirectAttributes.addFlashAttribute("successMessage", "User updated successfully.");
        return "redirect:/registration/showuser";
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        User user = userService.getUserById(id);
        if (user == null) {
            // Handle the case when the user is not found
            return "redirect:/registration/showuser";
        }

        userService.deleteUser(user);

        redirectAttributes.addFlashAttribute("successMessage", "User deleted successfully.");
        return "redirect:/registration/showuser";
    }

    @GetMapping("/password/{id}")
    public String showPasswordChangeForm(@PathVariable("id") Long id, Model model) {
        User user = userService.getUserById(id);
        if (user == null) {
            // Handle the case when the user is not found
            return "redirect:/registration/showuser";
        }
        model.addAttribute("user", user);
        return "changepassword";
    }

    @PostMapping("/password/{id}")
    public String changePassword(@PathVariable("id") Long id, 
                                 @RequestParam("email") String email,
                                 @RequestParam("oldPassword") String oldPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 RedirectAttributes redirectAttributes) {
        User user = userService.getUserById(id);
        if (user == null) {
            // Handle the case when the user is not found
            return "redirect:/registration/showuser";
        }

        if (!user.getEmail().equals(email)) {
            // Handle the case when the email does not match
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid email.");
            return "redirect:/registration/password/" + id;
        }

        if (!user.getPassword().equals(oldPassword)) {
            // Handle the case when the old password is incorrect
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid old password.");
            return "redirect:/registration/password/" + id;
        }

        user.setPassword(newPassword);
        userService.save(user);

        redirectAttributes.addFlashAttribute("successMessage", "Password changed successfully.");
        return "redirect:/registration/showuser";
    }
}
