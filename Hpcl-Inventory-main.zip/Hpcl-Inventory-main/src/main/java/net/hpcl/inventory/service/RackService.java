package net.hpcl.inventory.service;

public interface RackService {

}
