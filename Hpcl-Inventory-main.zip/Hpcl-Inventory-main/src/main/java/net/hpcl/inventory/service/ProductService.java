/*package net.javaguides.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import net.javaguides.springboot.model.Product;

@Service
public interface ProductService {
    Product createProduct(Product product);
    
    List<Product> getAllProductDetails();
    
    Optional<Product> getProductById(Long id);
    
    void updateProduct(Long id, Product updatedProduct);
    
    void deleteProduct(Long id);
    
    void deleteProductDetails(Long id);
    
    List<String> getProductNames();
}*/
package net.hpcl.inventory.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Product;

@Service
public interface ProductService {
    Product createProduct(Product product);

    List<Product> getAllProductDetails();

    Optional<Product> getProductById(Long id);

    void updateProduct(Long id, Product updatedProduct);

    void deleteProduct(Long id);

    void deleteProductDetails(Long id);

    List<String> getProductNames();

    List<String> getAllSnames();

    List<String> getAllNames();

    List<String> getAllRacksByWarehouse(String warehousename);
    
    List<Product> searchProducts(String keyword);
    List<Product> search(String keyword);
}

