package net.hpcl.inventory.service;

import java.util.List;

import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Warehouse;
@Service
public interface WarehouseService {

	    Warehouse createWarehouse(Warehouse warehouse);
	    boolean checkName(String name);
	    List<Warehouse> getAllWarehouseDetails();
	    List<String> getAllNames();
	    List<String> getAllRacksByWarehouse(String warehouseName);
	    void deleteWarehouse(Long id);

	}

