package net.hpcl.inventory.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import net.hpcl.inventory.model.Rack;
import net.hpcl.inventory.model.Warehouse;
import net.hpcl.inventory.repository.RackRepository;
import net.hpcl.inventory.repository.SubRackRepository;
import net.hpcl.inventory.repository.WarehouseRepository;

import java.util.List;
import java.util.Map;

@RestController
public class WarehouseRestController {

    private final WarehouseRepository warehouseRepository;
    @Autowired
    public WarehouseRestController(WarehouseRepository warehouseRepository, RackRepository rackRepository, SubRackRepository subRackRepository) {
        this.warehouseRepository = warehouseRepository;
    }

    @PostMapping("/submitWarehouseRacks")
    public String submitWarehouseRacks(@RequestBody Map<String, List<String>> rackData) {
        try {
            for (String warehouseName : rackData.keySet()) {
                Warehouse warehouse = new Warehouse();
                warehouse.setName(warehouseName);

                List<String> rackNames = rackData.get(warehouseName);

                for (String rackName : rackNames) {
                    Rack rack = new Rack();
                    rack.setName(rackName);
                    warehouse.getRacks().add(rack);
                   
                }
                Rack rack = new Rack();
                rack.setName("Defective Rack");
                warehouse.getRacks().add(rack);
                
                Rack rack2 = new Rack();
                rack2.setName("Salvaged Rack");
                warehouse.getRacks().add(rack2);
                
                
                warehouseRepository.save(warehouse);
            }

            return "Warehouse racks submitted successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error occurred while submitting warehouse racks!";
        }
        
    }
}
