package net.hpcl.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.hpcl.inventory.model.Rack;
@Repository
public interface RackRepository extends JpaRepository<Rack, Long> {
	public boolean existsByName(String name);
	Rack findByName(String name);
	@Query("SELECT r.name FROM Rack r")
    List<String> getAllRackNames();
}
