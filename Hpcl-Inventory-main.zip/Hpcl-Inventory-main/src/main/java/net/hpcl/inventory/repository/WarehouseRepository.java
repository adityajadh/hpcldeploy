package net.hpcl.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.hpcl.inventory.model.Warehouse;

@Repository
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {
	public boolean existsByName(String name);
	Warehouse findByName(String name);
	@Query("SELECT w.name FROM Warehouse w")
    List<String> getAllWarehouseNames();
}
