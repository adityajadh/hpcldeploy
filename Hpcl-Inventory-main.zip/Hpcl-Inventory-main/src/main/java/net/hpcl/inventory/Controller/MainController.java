package net.hpcl.inventory.Controller;

import java.util.List;
import java.util.Optional;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import net.hpcl.inventory.model.Analysis;
import net.hpcl.inventory.model.Product;
import net.hpcl.inventory.model.Supplier;
import net.hpcl.inventory.model.Warehouse;
import net.hpcl.inventory.repository.ProductRepository;
import net.hpcl.inventory.repository.SupplierRepository;
import net.hpcl.inventory.service.AnalysisService;
import net.hpcl.inventory.service.ProductService;
import net.hpcl.inventory.service.SupplierService;
import net.hpcl.inventory.service.WarehouseService;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class MainController {
	private static final String MatrixToImageWriter = null;
	@Autowired
	private SupplierRepository supplierRepository;
	@Autowired
	private SupplierService supplierService;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ProductService productService;
	@Autowired
	private WarehouseService warehouseService;
	@Autowired   
	private AnalysisService analysisService;
	
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/index")
	public String index() {
		return "index";
	}
////////////////////////////////////Supplier/////////////////////////////////////////////////////////////////////////////////	
	@GetMapping("/addsupplier")
	public String addsupplier()
	{
		return "addsupplier";
	}
	
	
	@PostMapping("/createUser")
	public String createUser(@ModelAttribute Supplier supplier, @RequestParam("img") MultipartFile img, HttpSession session) {
	    try {
	        String imageName = img.getOriginalFilename();
	        supplier.setImageName(imageName);
	        
	        Supplier createdSupplier = supplierService.createUser(supplier);
	        if (createdSupplier != null) {
	            String uploadDir = "static/img";
	            String uploadPath = new ClassPathResource(uploadDir).getFile().getAbsolutePath();
	            Path filePath = Paths.get(uploadPath + File.separator + imageName);
	            Files.copy(img.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	            session.setAttribute("msg", "User and Image Upload Successfully");
	        } else {
	            session.setAttribute("msg", "Failed to create user");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        session.setAttribute("msg", "Error occurred while uploading user and image");
	    }
	    
	    return "redirect:/addsupplier?success";
	}

	
	@GetMapping("/showsupplier")
	public String getSupplierDetails(Model model) {
	    List<Supplier> supplierDetails = supplierService.getAllSupplierDetails();
	    List<Supplier> list = supplierRepository.findAll();
	    model.addAttribute("supplierDetails", supplierDetails);
	    model.addAttribute("list", list);
	    return "showsupplier";
	}
	
	@GetMapping("/supplierDetails/{id}/edit")
	public String showEditSupplierForm(@PathVariable("id") Long id, Model model) {
	    Optional<Supplier> supplierOptional = supplierService.getSupplierById(id);
	    
	    if (supplierOptional.isPresent()) {
	        Supplier supplier = supplierOptional.get();
	        model.addAttribute("supplier", supplier);
	    }
	    
	    return "editSupplier";
	}

	@PostMapping("/supplierDetails/{id}/update")
	public String updateSupplier(@PathVariable("id") Long id, @ModelAttribute Supplier updatedSupplier, @RequestParam("img") MultipartFile img, HttpSession session) {
	    try {
	        Optional<Supplier> supplierOptional = supplierService.getSupplierById(id);
	        
	        if (supplierOptional.isPresent()) {
	            Supplier supplier = supplierOptional.get();
	            String imageName = img.getOriginalFilename();
	            supplier.setImageName(imageName);
	            
	            supplier.setSname(updatedSupplier.getSname());
	            supplier.setContact_no(updatedSupplier.getContact_no());
	            supplier.setErp_code(updatedSupplier.getErp_code());
	            supplier.setSaddress(updatedSupplier.getSaddress());
	            supplier.setEmail(updatedSupplier.getEmail());
	            supplier.setSupplier_type(updatedSupplier.getSupplier_type());
	            supplier.setGst_no(updatedSupplier.getGst_no());
	            // Update other properties of the Supplier entity as needed
	            
	            Supplier updated = supplierService.updateSupplier(id, supplier);
	            
	            if (updated != null) {
	                String uploadDir = "static/img";
	                String uploadPath = new ClassPathResource(uploadDir).getFile().getAbsolutePath();
	                Path filePath = Paths.get(uploadPath + File.separator + imageName);
	                Files.copy(img.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	                session.setAttribute("msg", "Supplier and Image updated successfully");
	            } else {
	                session.setAttribute("msg", "Failed to update supplier");
	            }
	        } else {
	            session.setAttribute("msg", "Supplier not found");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        session.setAttribute("msg", "Error occurred while updating supplier and image");
	    }
	    
	    return "redirect:/showsupplier";
	}

	
	@GetMapping("/supplierDetails/{id}/delete")
	public String deletesupplierDetails(@PathVariable Long id) {
		supplierService.deletesupplierDetails(id);
		return "redirect:/showsupplier";
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@GetMapping("/addproduct")
	public String product(Model model) {
	    List<String> supplierNames = supplierService.getAllSnames();
	    model.addAttribute("supplierNames", supplierNames);

	    List<String> warehousesNames = warehouseService.getAllNames();
	    model.addAttribute("warehousesNames", warehousesNames);

	    model.addAttribute("analysisA", 250);
	    model.addAttribute("analysisB", 500);
	    model.addAttribute("analysisC", 1000);

	    return "addproduct";
	}
	
	@GetMapping("/getallRacksByWarehouse")
	@ResponseBody
	public String getallRacksByWarehouse(@RequestParam("warehousename") String warehousename) {
	    List<String> racknames = warehouseService.getAllRacksByWarehouse(warehousename);

	    Gson gson = new Gson();
	    String jsonRacknames = gson.toJson(racknames);
	    return jsonRacknames;
	}

	

	@GetMapping("/deletewarehouse")
	@ResponseBody
	public String deletewarehouse(@RequestParam("id") Long id) {
	 warehouseService.deleteWarehouse(id);
		//   List<String> racknames = warehouseService.getAllRacksByWarehouse(warehousename);

	    Gson gson = new Gson();
	    String jsonRacknames = gson.toJson("deleted");
	    return jsonRacknames;
	}

	@PostMapping("/createProduct")
	public String createProduct(@ModelAttribute Product product, @RequestParam("img") MultipartFile img, HttpSession session) {
	    try {
	        String imageName = img.getOriginalFilename();
	        product.setImageName(imageName);

	        Product createdProduct = productService.createProduct(product);
	        if (createdProduct != null) {
	            String uploadDir = "static/img";
	            String uploadPath = new ClassPathResource(uploadDir).getFile().getAbsolutePath();
	            Path filePath = Paths.get(uploadPath + File.separator + imageName);
	            Files.copy(img.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
	            session.setAttribute("msg", "Product and Image Upload Successfully");
	        } else {
	            session.setAttribute("msg", "Failed to create product");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        session.setAttribute("msg", "Error occurred while uploading product and image");
	    }

	    return "redirect:/addproduct?success";
	}

	@GetMapping("/productDetails/{id}/edit")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
	    try {
	        Optional<Product> product = productService.getProductById(id);
	        if (product.isPresent()) { 
	            model.addAttribute("product", product.get());

	            List<String> supplierNames = supplierService.getAllSnames();
	            model.addAttribute("supplierNames", supplierNames);

	            List<String> warehousesNames = warehouseService.getAllNames();
	            model.addAttribute("warehousesNames", warehousesNames);

	            List<String> rackNames = warehouseService.getAllRacksByWarehouse(product.get().getWarehouse_name());
	            model.addAttribute("rackNames", rackNames);

	            return "editForm";
	        } else {
	            model.addAttribute("error", "Product not found");
	            return "errorPage";
	        }
	    } catch (Exception e) {
	        model.addAttribute("error", "An error occurred");
	        return "errorPage";
	    }
	}

	@PostMapping("/productDetails/{id}/update")
	public String updateProduct(@PathVariable("id") Long id, @ModelAttribute("product") Product updatedProduct) {
	    try {
	        productService.updateProduct(id, updatedProduct);
	        return "redirect:/showproduct";
	    } catch (Exception e) {
	        // Handle any exceptions that occur during the update process
	        return "errorPage";
	    }
	}

	@GetMapping("/productDetails/{id}/delete")
	public String deleteProductDetails(@PathVariable Long id) {   
	    productService.deleteProductDetails(id);
	    return "redirect:/showproduct";
	}

	@GetMapping("/showproduct")
	public String getProductDetails(Model model) {
	    List<Product> productDetails = productService.getAllProductDetails();
	    model.addAttribute("productDetails", productDetails);
	    return "showproduct";
	}

//////////////////////////////////////////////Warehouse And Racks////////////////////////////////////////////////////////////
	@GetMapping("/addwarehouse")
    public String addWarehouse() {
        return "addwarehouse";
    }

    @GetMapping("/showwarehouse")
    public String getWarehouseDetails(Model model) {
        @SuppressWarnings("unused")
		List<String> warehouseName = warehouseService.getAllNames();
        //model.addAttribute("warehouseNames", warehouseNames);
        
        List<Warehouse> warehouseDetails = warehouseService.getAllWarehouseDetails();
        model.addAttribute("warehouseDetails", warehouseDetails);
        
        return "showwarehouse";
    }
    
    @GetMapping("/showracks/{warehouseName}")
    public String getRacksByWarehouse(@PathVariable("warehouseName") String warehouseName, Model model) {
        List<String> racks = warehouseService.getAllRacksByWarehouse(warehouseName);
        model.addAttribute("racks", racks);
        
        return "showracks";
    }
/////////////////////////////////////Profile Setting/////////////////////////////////////////////////////////////////////// 
    @GetMapping("/profilesetting")
    public String profilesetting() {
    	return "profilesetting";
    }
 /////////////////////////////////Analysis///////////////////////////////////////////////////////////////////////////////////  
    @GetMapping("/analysis")
    public String analysis() {
    	return "analysis";
    }
    @GetMapping
    public String getAllAnalysis(Model model) {
        model.addAttribute("analyses", analysisService.getAllAnalysis());
        return "analysisList";
    }

    @GetMapping("/{id}")
    public String getAnalysisById(@PathVariable Long id, Model model) {
        Analysis analysis = analysisService.getAnalysisById(id);
        model.addAttribute("analysis", analysis);
        return "analysisDetails";
    }

    @PostMapping("/analysis")
    public String saveAnalysis(Analysis analysis) { 
        analysisService.saveAnalysis(analysis);
        return "analysis";
    }

    @GetMapping("/{id}/delete")
    public String deleteAnalysis(@PathVariable Long id) {
        analysisService.deleteAnalysis(id);
        return "redirect:/analysis";
    }
       
//////////////////////////////////////////////////////Product Report///////////////////////////////////////////////////////    

    @GetMapping("/productreport")
    public String productReport(Model model) {
        List<String> productNames = productService.getProductNames();
        model.addAttribute("productNames", productNames);
        return "productreport";
    }

////////////////////////////////////////////////////Product List//////////////////////////////////////////////////////////////
    
    @GetMapping("/productlist")
    public String productList(Model model) {
        List<String> productNames = productService.getProductNames();
        List<String> supplierNames = supplierService.getAllSnames();

        model.addAttribute("productNames", productNames);
        model.addAttribute("supplierNames", supplierNames);

        return "productlist";
    }
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @GetMapping("/generateQRCode")
    public void generateQRCode(HttpServletResponse response, @RequestParam("data") String data) {
        // Set QR code options
        int width = 300;
        int height = 300;
        String format = "png";
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);

        try {
            // Generate QR code
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, width, height, hints);

            // Convert BitMatrix to BufferedImage
            int qrCodeWidth = bitMatrix.getWidth();
            int qrCodeHeight = bitMatrix.getHeight();
            BufferedImage qrCodeImage = new BufferedImage(qrCodeWidth, qrCodeHeight, BufferedImage.TYPE_INT_RGB);

            for (int x = 0; x < qrCodeWidth; x++) {
                for (int y = 0; y < qrCodeHeight; y++) {
                    qrCodeImage.setRGB(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                }
            }

            // Save the image to the static/img folder
            String uploadDir = "static/img";
            String imageName = "qr_code.png";
            String uploadPath = new ClassPathResource(uploadDir).getFile().getAbsolutePath();
            Path filePath = Paths.get(uploadPath + File.separator + imageName);
            ImageIO.write(qrCodeImage, format, filePath.toFile());

            // Set response headers for image content type
            response.setContentType("image/png");
            response.setHeader("Content-Disposition", "attachment; filename=qr_code.png");

            // Write the image to the response output stream
            ImageIO.write(qrCodeImage, format, response.getOutputStream());
            response.getOutputStream().flush();
            response.getOutputStream().close();
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
    }
 ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @GetMapping("/inscann")
    public String inscann(Model model) {
        List<Product> productDetails = productService.getAllProductDetails();
        model.addAttribute("productDetails", productDetails);
        return "inscann";
    }

    @GetMapping("/search")
    public String viewProduct(@RequestParam("keyword") String keyword, Model model) {
        List<Product> listProduct = productService.search(keyword);
      
        model.addAttribute("keyword", keyword);
        model.addAttribute("productDetails", listProduct);

        return "inscann";
    }

   /* @GetMapping("/productDetails/{id}/edit")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
	    try {
	        Optional<Product> product = productService.getProductById(id);
	        if (product.isPresent()) { 
	            model.addAttribute("product", product.get());
	        }*/
	   
    @GetMapping("/inscannadd")
    public String inscannadd(@RequestParam("productId") long productId, Model model) {
    	
    	 Optional<Product> product = productService.getProductById(productId);
    	 
    	 if (product.isPresent()) {
             
    		 model.addAttribute("selectedProduct", product.get());

    	        // Add other required model attributes
    	      List<Product> productDetails = productService.getAllProductDetails();
    	       model.addAttribute("productDetails", productDetails);

    	        List<String> supplierNames = supplierService.getAllSnames();
    	        model.addAttribute("supplierNames", supplierNames);

    	        
         } else {
             
         }
    	 
    	 
       
        
       
        return "inscannadd";
    }

    @GetMapping("/productDetails/{id}/add")
    public String showAddForm(@PathVariable("id") Long id, Model model) {
        try {
            Optional<Product> product = productService.getProductById(id);
            if (product.isPresent()) {
                model.addAttribute("product", product.get());

                List<String> supplierNames = supplierService.getAllSnames();
                model.addAttribute("supplierNames", supplierNames);

                return "inscannadd";
            } else {
                model.addAttribute("error", "Product not found");
                return "errorPage";
            }
        } catch (Exception e) {
            model.addAttribute("error", "An error occurred");
            return "errorPage";
        }
    }
}
