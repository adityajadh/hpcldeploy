package net.hpcl.inventory.service;

import java.util.List;
import java.util.Optional;

import net.hpcl.inventory.model.Supplier;

public interface SupplierService {
    Supplier createUser(Supplier supplier);
    boolean checkEmail(String email);
    List<Supplier> getAllSupplierDetails();
    Optional<Supplier> getSupplierById(Long id);
    Supplier updateSupplier(Long id, Supplier updatedSupplier);
    void deleteSupplier(Long id);
    void deletesupplierDetails(Long id);
    List<String> getAllSnames();
}
