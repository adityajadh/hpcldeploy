/*package net.javaguides.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.javaguides.springboot.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("SELECT p.pname FROM Product p")
    List<String> getProductNames();

    @Query("SELECT p.supplier FROM Product p")
    List<String> getAllSnames();

    @Query("SELECT DISTINCT p.warehouse_name FROM Product p")
    List<String> getAllNames();

    @Query("SELECT p.rack_number FROM Product p WHERE p.warehouse_name = ?1")
    List<String> getAllRacksByWarehouse(String warehousename);

}
*/
package net.hpcl.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.hpcl.inventory.model.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("SELECT p.pname FROM Product p")
    List<String> getProductNames();

    @Query("SELECT p.supplier FROM Product p")
    List<String> getAllSnames();

    @Query("SELECT DISTINCT p.warehouse_name FROM Product p")
    List<String> getAllNames();

    @Query("SELECT p.rack_number FROM Product p WHERE p.warehouse_name = ?1")
    List<String> getAllRacksByWarehouse(String warehousename);

    @Query("SELECT p FROM Product p WHERE LOWER(p.pname) LIKE %?1% OR p.id LIKE %?1%")
   // List<Product> findByNameContainingIgnoreCaseOrIdContainingIgnoreCase(String keyword);

	List<Product> findByNameContainingIgnoreCaseOrIdContainingIgnoreCase(String keyword, String keyword2);
    
    @Query("SELECT p FROM Product p WHERE CONCAT(p.pname,'',p.id,'',p.supplier)LIKE %?1%")
    List<Product>search(String keyword);
}
