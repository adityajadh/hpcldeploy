package net.hpcl.inventory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import net.hpcl.inventory.model.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Long>{
	public boolean existsByEmail(String email);
	Supplier findByEmail(String email);
	@Query("SELECT s.sname FROM Supplier s")
    List<String> getAllSupplierNames();
}