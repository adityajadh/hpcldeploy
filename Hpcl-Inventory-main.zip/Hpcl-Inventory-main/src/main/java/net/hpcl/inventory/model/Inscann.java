 package net.hpcl.inventory.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="inscann")
	
public class Inscann {
 	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

	private String imageName;
    private String pname;
    private String warehouseName;
    private String rackNumber;
    private int openingStock;
    private String date;
    private String invoice;
    private String gatePassNo;
    private String quantity;
    private String supplier;
	@Override
	public String toString() {
		return "Inscann [imageName=" + imageName + ", pname=" + pname + ", warehouseName=" + warehouseName
				+ ", rackNumber=" + rackNumber + ", openingStock=" + openingStock + ", date=" + date + ", invoice="
				+ invoice + ", gatePassNo=" + gatePassNo + ", quantity=" + quantity + ", supplier=" + supplier + "]";
	}
	public Inscann() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Inscann(String imageName, String pname, String warehouseName, String rackNumber, int openingStock,
			String date, String invoice, String gatePassNo, String quantity, String supplier) {
		super();
		this.imageName = imageName;
		this.pname = pname;
		this.warehouseName = warehouseName;
		this.rackNumber = rackNumber;
		this.openingStock = openingStock;
		this.date = date;
		this.invoice = invoice;
		this.gatePassNo = gatePassNo;
		this.quantity = quantity;
		this.supplier = supplier;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(String warehouseName) {
		this.warehouseName = warehouseName;
	}
	public String getRackNumber() {
		return rackNumber;
	}
	public void setRackNumber(String rackNumber) {
		this.rackNumber = rackNumber;
	}
	public int getOpeningStock() {
		return openingStock;
	}
	public void setOpeningStock(int openingStock) {
		this.openingStock = openingStock;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getGatePassNo() {
		return gatePassNo;
	}
	public void setGatePassNo(String gatePassNo) {
		this.gatePassNo = gatePassNo;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
    
    
}
