  package net.hpcl.inventory.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	 	private long id;
	    private String product_id;
	 	private String opening_stock;
	 	private String quantity;
	 	private String Price;
	    private String pname;
	    private String warehouse_name;
	    private String rack_number;
	    private String machine_name;
	    private String supplier;
	    private String VDE;
	    private String imageName;
		@Override
		public String toString() {
			return "Product [id=" + id + ", product_id=" + product_id + ", opening_stock=" + opening_stock
					+ ", quantity=" + quantity + ", Price=" + Price + ", pname=" + pname
					+ ", warehouse_name=" + warehouse_name + ", rack_number=" + rack_number + ", machine_name="
					+ machine_name + ", supplier=" + supplier + ", VDE=" + VDE + "]";
		}
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getProduct_id() {
			return product_id;
		}
		public void setProduct_id(String product_id) {
			this.product_id = product_id;
		}
		public String getOpening_stock() {
			return opening_stock;
		}
		public void setOpening_stock(String opening_stock) {
			this.opening_stock = opening_stock;
		}
		public String getQuantity() {
			return quantity;
		}
		public void setQuantity(String quantity) {
			this.quantity = quantity;
		}
		public String getPrice() {
			return Price;
		}
		public void setPrice(String price) {
			Price = price;
		}
		public String getPname() {
			return pname;
		}
		public void setPname(String pname) {
			this.pname = pname;
		}
		public String getWarehouse_name() {
			return warehouse_name;
		}
		public void setWarehouse_name(String warehouse_name) {
			this.warehouse_name = warehouse_name;
		}
		public String getRack_number() {
			return rack_number;
		}
		public void setRack_number(String rack_number) {
			this.rack_number = rack_number;
		}
		public String getMachine_name() {
			return machine_name;
		}
		public void setMachine_name(String machine_name) {
			this.machine_name = machine_name;
		}
		public String getSupplier() {
			return supplier;
		}
		public void setSupplier(String supplier) {
			this.supplier = supplier;
		}
		public String getVDE() {
			return VDE;
		}
		public void setVDE(String vDE) {
			VDE = vDE;
		}
		public String getImageName() {
			return imageName;
		}
		public void setImageName(String imageName) {
			this.imageName = imageName;
		}
	    
}
