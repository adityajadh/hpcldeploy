package net.hpcl.inventory.service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.hpcl.inventory.model.Rack;
import net.hpcl.inventory.model.Warehouse;
import net.hpcl.inventory.repository.WarehouseRepository;
@Service
public class WarehouseServiceImpl implements WarehouseService {
	
	    @Autowired
	    private WarehouseRepository warehouseRepository;

	    @Override
	    public Warehouse createWarehouse(Warehouse warehouse) {
	        return warehouseRepository.save(warehouse);
	    }

	    @Override
	    public boolean checkName(String name) {
	        return warehouseRepository.existsByName(name);
	    }

	    @Override
	    public List<Warehouse> getAllWarehouseDetails() {
	        return warehouseRepository.findAll();
	    }

	    @Override
	    public List<String> getAllNames() {
	        return warehouseRepository.findAll().stream()
	                .map(Warehouse::getName)
	                .collect(Collectors.toList());
	    }

	    @Override
	    public List<String> getAllRacksByWarehouse(String warehouseName) {
	        Warehouse warehouse = warehouseRepository.findByName(warehouseName);
	        if (warehouse != null) {
	            return warehouse.getRacks().stream()
	                    .map(Rack::getName)
	                    .collect(Collectors.toList());
	        }
	        return Collections.emptyList();
	    }

		@Override
		public void deleteWarehouse(Long id) {
			// TODO Auto-generated method stub
			warehouseRepository.deleteById(id);
		}
	}
